// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "Masked priming task",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 132.8,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Welcome",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Wecome0",
      "timeout": "500"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 141.69,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Welcome.",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Wecome1",
      "timeout": "500"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 150.58,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Welcome..",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Wecome2",
      "timeout": "500"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 159.47,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Welcome...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Wecome3",
      "timeout": "500"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 634.93,
          "height": 371.72,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "In this experiment, you will see some words, \nseparated by #####.\n\nWhen you see the word, \nyour job is to say whether it is something \nnatural or man-made.\n\nPress any key to continue...\n",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions1"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 501.1,
          "height": 371.72,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "When you see the word,\n\npress the \"n\" key if it is natural.\n\npress the \"m\" key if it is man-made.\n\n\nPress any key to continue...\n",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions 1a"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 727.46,
          "height": 329.78,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Natural could be things like plants, animals, rocks.. \nanything from the natural world.\n\nMan-made refers to anything produced by people: \nobjects, tools, machines.. \nanything that requires a person to make it.\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions2"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 798.62,
          "height": 539.51,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Try to respond as quickly and accurately as you can.\n\nYou need to respond within two seconds.\n\nSometimes, you will make a mistake. \nThat's ok. \n\nSometimes, you might be unsure what the word means. \nThat's ok too.\n\nJust go on to the next one.\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions3"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 675.95,
          "height": 245.89,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "The whole experiment will take you around \n6-7 minutes to complete.\n\nThere is a break when you are halfway through.\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions4"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 643.41,
          "height": 455.62,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Before you start the real experiment, \nthere is a quick practice round.\n\nRemember:\n\npress \"n\" if the word is something natural\n\npress \"m\" if the word is something man-made\n\nPress SPACE to start the practice round...\n",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Space)": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions5"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "prime": "abjdhjs",
          "target": "HORSE",
          "condition": "practice",
          "soa_condition": "practice",
          "congruence": "practice",
          "correct_response": "n"
        },
        {
          "prime": "iweonf",
          "target": "BOAT",
          "condition": "practice",
          "soa_condition": "practice",
          "congruence": "practice",
          "correct_response": "m"
        },
        {
          "prime": "nvoiuh",
          "target": "HOUSE",
          "condition": "practice",
          "soa_condition": "practice",
          "congruence": "practice",
          "correct_response": "m"
        },
        {
          "prime": "snjghf",
          "target": "SHEEP",
          "condition": "practice",
          "soa_condition": "practice",
          "congruence": "practice",
          "correct_response": "n"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Practice Loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Practice Sequence",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 18.69,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "+",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "fixation",
            "timeout": "539"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 106.78,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "######",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "mask1",
            "timeout": "32"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 307.71,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "${ parameters.prime }",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "prime",
            "timeout": "32"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 88.99,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "#####",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "mask2",
            "timeout": "32"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 309.52,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "${ parameters.target }",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "keypress(m,n)": "target_response"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "target",
            "correctResponse": "${ parameters.correct_response }"
          }
        ]
      }
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 666.99,
          "height": 413.67,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Practice complete!\n\nNow you are ready to start the real experiment.\n\nRemember to answer as quickly as you can, \nas you only have two seconds to respond.\n\nEnjoy!\n\nPress any key to begin..",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Practice complete"
    },
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Experiment Sequence",
      "shuffle": true,
      "content": [
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Short Sequence",
          "content": [
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "prime": "seed",
                  "target": "SEED",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "soil",
                  "target": "SOIL",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "deer",
                  "target": "DEER",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "creek",
                  "target": "CREEK",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "worm",
                  "target": "WORM",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "whale",
                  "target": "WHALE",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "puppy",
                  "target": "PUPPY",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "frog",
                  "target": "FROG",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "hawk",
                  "target": "HAWK",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "goose",
                  "target": "GOOSE",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "daisy",
                  "target": "DAISY",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "cave",
                  "target": "CAVE",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "corn",
                  "target": "CORN",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "grass",
                  "target": "GRASS",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "tiger",
                  "target": "TIGER",
                  "condition": "Con_Nat",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "rope",
                  "target": "ROPE",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "cable",
                  "target": "CABLE",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "tower",
                  "target": "TOWER",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "belt",
                  "target": "BELT",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "doll",
                  "target": "DOLL",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "tank",
                  "target": "TANK",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "bike",
                  "target": "BIKE",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "sword",
                  "target": "SWORD",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "bread",
                  "target": "BREAD",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "gate",
                  "target": "GATE",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "toast",
                  "target": "TOAST",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "mail",
                  "target": "MAIL",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "paint",
                  "target": "PAINT",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "coat",
                  "target": "COAT",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "drug",
                  "target": "DRUG",
                  "condition": "Con_Synth",
                  "soa_condition": "short",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "kiosk",
                  "target": "SOFA",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "ladle",
                  "target": "CAFÉ",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "silo",
                  "target": "PLAZA",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "sash",
                  "target": "CLOTH",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "wharf",
                  "target": "RAZOR",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "spade",
                  "target": "SHELF",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "patio",
                  "target": "SPOON",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "harp",
                  "target": "SNAIL",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "rake",
                  "target": "HUSKY",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "ruler",
                  "target": "PANSY",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "arena",
                  "target": "VINE",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "spear",
                  "target": "MOTH",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "rail",
                  "target": "SQUID",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "sewer",
                  "target": "CORAL",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "torch",
                  "target": "CHIMP",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "fern",
                  "target": "PETAL",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "lime",
                  "target": "GULLY",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "berry",
                  "target": "OTTER",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "poppy",
                  "target": "DINGO",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "cobra",
                  "target": "TWIG",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "grape",
                  "target": "LLAMA",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "finch",
                  "target": "SLOTH",
                  "condition": "Nat_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "melon",
                  "target": "HOSE",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "crow",
                  "target": "YACHT",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "camel",
                  "target": "BENCH",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "leaf",
                  "target": "COIN",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "toad",
                  "target": "GLOVE",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "peach",
                  "target": "SHED",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "mice",
                  "target": "TOOLS",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "water",
                  "target": "MEDAL",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "short",
                  "congruence": "incongruent",
                  "correct_response": "m"
                }
              ],
              "sample": {
                "mode": "draw-shuffle"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Short Loop",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Trial Sequence",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 18.69,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "+",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "fixation",
                    "timeout": "539"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 106.78,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "######",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "mask1",
                    "timeout": "32"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 307.71,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ parameters.prime }",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "prime",
                    "timeout": "32"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 88.99,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "#####",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "mask2",
                    "timeout": "32"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 309.52,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ parameters.target }",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress(m,n)": "target_response"
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "target",
                    "correctResponse": "${ parameters.correct_response }",
                    "timeout": "2000"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 25,
                  "top": 0,
                  "angle": 0,
                  "width": 2,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 636.76,
                  "height": 413.67,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Break time!\n\nIf this is the first time you see this screen,\ntake a quick break, and press the\nspace key\nwhen you are ready to continue.\n\nIf this is the second time you see this screen,\nyou're done!\nPress the space key to end the experiment.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Break"
            }
          ]
        },
        {
          "type": "lab.flow.Sequence",
          "files": {},
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "Long Sequence",
          "content": [
            {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "prime": "crab",
                  "target": "CRAB",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "swan",
                  "target": "SWAN",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "slug",
                  "target": "SLUG",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "peas",
                  "target": "PEAS",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "reef",
                  "target": "REEF",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "clam",
                  "target": "CLAM",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "hare",
                  "target": "HARE",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "plum",
                  "target": "PLUM",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "moss",
                  "target": "MOSS",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "boar",
                  "target": "BOAR",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "wasp",
                  "target": "WASP",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "pear",
                  "target": "PEAR",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "earth",
                  "target": "EARTH",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "stick",
                  "target": "STICK",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "stone",
                  "target": "STONE",
                  "condition": "Con_Nat",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "n"
                },
                {
                  "prime": "arrow",
                  "target": "ARROW",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "stove",
                  "target": "STOVE",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "jeans",
                  "target": "JEANS",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "ferry",
                  "target": "FERRY",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "broom",
                  "target": "BROOM",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "scarf",
                  "target": "SCARF",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "crate",
                  "target": "CRATE",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "canoe",
                  "target": "CANOE",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "linen",
                  "target": "LINEN",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "apron",
                  "target": "APRON",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "flute",
                  "target": "FLUTE",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "stair",
                  "target": "STAIR",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "flask",
                  "target": "FLASK",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "canon",
                  "target": "CANON",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "tongs",
                  "target": "TONGS",
                  "condition": "Con_Synth",
                  "soa_condition": "long",
                  "congruence": "congruent",
                  "correct_response": "m"
                },
                {
                  "prime": "cake",
                  "target": "TRASH",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "desk",
                  "target": "CANDY",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "bell",
                  "target": "WHEEL",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "roof",
                  "target": "PIANO",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "shoe",
                  "target": "COUCH",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "wire",
                  "target": "CABIN",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "taxi",
                  "target": "CHAIN",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "deck",
                  "target": "PLATE",
                  "condition": "Inc_Synth_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "bowl",
                  "target": "WOLF",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "pipe",
                  "target": "LION",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "mall",
                  "target": "BUSH",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "sink",
                  "target": "LAMB",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "fort",
                  "target": "GOAT",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "soap",
                  "target": "PONY",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "barn",
                  "target": "TUNA",
                  "condition": "Inc_Synth_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "n"
                },
                {
                  "prime": "storm",
                  "target": "LAND",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "ocean",
                  "target": "TREE",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "fruit",
                  "target": "BEAR",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "bunny",
                  "target": "ROSE",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "shark",
                  "target": "HILL",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "sheep",
                  "target": "BULL",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "shell",
                  "target": "DIRT",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "lemon",
                  "target": "DUCK",
                  "condition": "Inc_Nat_Nat",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "cloud",
                  "target": "MOTEL",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "eagle",
                  "target": "WAGON",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "swamp",
                  "target": "DRILL",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "olive",
                  "target": "MOTOR",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "wheat",
                  "target": "BRICK",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "flood",
                  "target": "SKIRT",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                },
                {
                  "prime": "moose",
                  "target": "PORCH",
                  "condition": "Inc_Nat_Synth",
                  "soa_condition": "long",
                  "congruence": "incongruent",
                  "correct_response": "m"
                }
              ],
              "sample": {
                "mode": "draw-shuffle"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Long Loop",
              "shuffleGroups": [],
              "template": {
                "type": "lab.flow.Sequence",
                "files": {},
                "responses": {
                  "": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Trial Sequence",
                "content": [
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 18.69,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "+",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "fixation",
                    "timeout": "539"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 106.78,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "######",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "mask1",
                    "timeout": "32"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 307.71,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ parameters.prime }",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "prime",
                    "timeout": "32"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 88.99,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "#####",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "mask2",
                    "timeout": "32"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "": ""
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "DELAY",
                    "timeout": "80"
                  },
                  {
                    "type": "lab.canvas.Screen",
                    "content": [
                      {
                        "type": "i-text",
                        "left": 0,
                        "top": 0,
                        "angle": 0,
                        "width": 309.52,
                        "height": 36.16,
                        "stroke": null,
                        "strokeWidth": 1,
                        "fill": "black",
                        "text": "${ parameters.target }",
                        "fontStyle": "normal",
                        "fontWeight": "normal",
                        "fontSize": 32,
                        "fontFamily": "sans-serif",
                        "lineHeight": 1.16,
                        "textAlign": "center"
                      }
                    ],
                    "viewport": [
                      800,
                      600
                    ],
                    "files": {},
                    "responses": {
                      "keypress(m,n)": "target_response"
                    },
                    "parameters": {},
                    "messageHandlers": {},
                    "title": "target",
                    "correctResponse": "${ parameters.correct_response }"
                  }
                ]
              }
            },
            {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 25,
                  "top": 0,
                  "angle": 0,
                  "width": 2,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                },
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 636.76,
                  "height": 413.67,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "Break time!\n\nIf this is the first time you see this screen,\ntake a quick break, and press the\nspace key\nwhen you are ready to continue.\n\nIf this is the second time you see this screen,\nyou're done!\nPress the space key to end the experiment.",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Break"
            }
          ]
        }
      ]
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())