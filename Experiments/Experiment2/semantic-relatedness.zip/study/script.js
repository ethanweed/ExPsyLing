// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 766.54,
          "height": 245.89,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Welcome!\nIn this experiment, you will see sets of words, like this:\n\nwindow-piano\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions1"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 718.49,
          "height": 329.78,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Sometimes they will be real words, sometimes not.\n\nSomtimes there will be one real word\nand one nonsense word, like this:\n\nwindow-blargo\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions2"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 675.87,
          "height": 287.83,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "If both words are real words in English, like this:\n\nwindow-piano\n\npress the \"y\" key\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions3"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 780.89,
          "height": 497.56,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "If one or both of the words is not a real word in English,\nlike this:\n\nwindow-blargo\n\nor these:\n\njupsal-clotrop\n\nPress the \"n\" key\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions4"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 553.19,
          "height": 329.78,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "The experiment takes about 5 minutes.\n\nTry not to make any mistakes,\nbut don't worry if you do make a few.\n\nWe all make mistakes!\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions5"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 551.41,
          "height": 162,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "You will see a happy or sad smiley,\nto tell if you got the answer right or not.\n\nPress any key to continue...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions6"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 640.37,
          "height": 329.78,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "First, let's try a practice round.\n\nRemember:\n\n\"y\": two real words\n\"n\": one or two nonsense words\n\nPress any key when you are ready to begin...",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions7"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "counterbalance": "1",
          "": ""
        },
        {
          "counterbalance": "2",
          "": ""
        },
        {
          "counterbalance": "3",
          "": ""
        }
      ],
      "sample": {
        "mode": "draw-shuffle",
        "n": "1"
      },
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Counterbalance Loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Trial Sequence",
        "content": [
          {
            "type": "lab.flow.Loop",
            "templateParameters": [
              {
                "stim": "buy-sell",
                "condition": "Related",
                "block": "practice",
                "correct_response": "yes"
              },
              {
                "stim": "table-chair",
                "condition": "Related",
                "block": "practice",
                "correct_response": "yes"
              },
              {
                "stim": "shark-dull",
                "condition": "Unrelated",
                "block": "practice",
                "correct_response": "yes"
              },
              {
                "stim": "sand-pepper",
                "condition": "Unrelated",
                "block": "practice",
                "correct_response": "yes"
              },
              {
                "stim": "ip-bown",
                "condition": "Nonword",
                "block": "practice",
                "correct_response": "no"
              },
              {
                "stim": "hort-sain",
                "condition": "Nonword",
                "block": "practice",
                "correct_response": "no"
              }
            ],
            "sample": {
              "mode": "draw-shuffle"
            },
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Practice Loop",
            "shuffleGroups": [],
            "template": {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Trial",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 18.69,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black",
                      "text": "+",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Fixation",
                  "timeout": "500"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.35,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black",
                      "text": "${ parameters.stim }",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(y)": "yes",
                    "keypress(n)": "no"
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Stimulus",
                  "correctResponse": "${ parameters.correct_response }"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 585.65,
                      "height": 56.5,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "${ state.correct ? '😃' : '☹️'}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "50",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "ISI",
                  "timeout": "500",
                  "tardy": true
                }
              ]
            }
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 570.98,
                "height": 329.78,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "Ok, practice is over! \n\nTime for the real experiment.\nRemember:\ntwo real words: press \"y\"\none or two nonwords: press \"n\"\n\nPress any key to begin the experiment...",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "keypress": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "End of practice"
          },
          {
            "type": "lab.flow.Loop",
            "templateParameters": [
              {
                "stim": "hot-cold",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "young-old",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "lion-tiger",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "wash-rinse",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "lost-found",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "dusk-dawn",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "lock-key",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "circle-round",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "plant-flower",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "army-soldier",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "tall-short",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "spider-web",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "hammer-nail",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "life-death",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "true-false",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "earth-ground",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "joy-happy",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "leaf-stem",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "pot-cold",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "yours-old",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "limp-tiger",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "cash-rinse",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "cost-found",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "dish-dawn",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "luck-key",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "carves-round",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "slant-flower",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "till-short",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "sing-queen",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "glider-web",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "farmer-nail",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "purse-doctor",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "wife-death",
                "condition": "Unrelated",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "tune-false",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "early-ground",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "boy-happy",
                "condition": "Related",
                "block": "A",
                "correct_response": "yes"
              },
              {
                "stim": "rable-chait",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "slom-wast",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "yot-colp",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "boung-oid",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "fion-siger",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "jash-ronse",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "lont-gound",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "dosk-dawl",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "nock-kry",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "bircle-rount",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "plang-fluwer",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "arsy-goldier",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "talp-chort",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "fing-sueen",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "spiler-heb",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "gammer-yail",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "furse-loctor",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "barth-groond",
                "condition": "Nonword",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "man-wotar",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "rough-smoat",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "bread-bottin",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "bitter-sweax",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "green-gliss",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "large-smipo",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "bed-slorg",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "afraid-scobet",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "cabbage-lottir",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "door-wingew",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "moship-father",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "neibon-thread",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "brothog-sister",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "capsute-pill",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "boeh-ale",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "bosh-water",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "nirey-south",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "honip-bee",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "sconix-marble",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              },
              {
                "stim": "porry-cent",
                "condition": "Filler",
                "block": "A",
                "correct_response": "no"
              }
            ],
            "sample": {
              "mode": "draw-shuffle"
            },
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Block A Loop",
            "skip": "${parameters.counterbalance != 1}",
            "shuffleGroups": [],
            "template": {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Trial",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 18.69,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black",
                      "text": "+",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Fixation",
                  "timeout": "500"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.35,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black",
                      "text": "${ parameters.stim }",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(y)": "yes",
                    "keypress(n)": "no"
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Stimulus",
                  "correctResponse": "${ parameters.correct_response }"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 585.65,
                      "height": 56.5,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "${ state.correct ? '😃' : '☹️'}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "50",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "ISI",
                  "timeout": "500",
                  "tardy": true
                }
              ]
            }
          },
          {
            "type": "lab.flow.Loop",
            "templateParameters": [
              {
                "stim": "wine-grapes",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "dance-waltz",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "fat-thin",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "peace-war",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "pen-ink",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "good-bad",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "hop-skip",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "rip-tear",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "hill-mountain",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "scissors-cut",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "health-sickness",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "add-subtract",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "blue-sky",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "dark-night",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "high-low",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "trout-fish",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "black-white",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "boy-girl",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "dog-cat",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "hard-soft",
                "condition": "Related",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "lean-stem",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "fine-grapes",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "ranch-waltz",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "bat-thin",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "peach-war",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "men-ink",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "gold-bad",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "mop-skip",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "rid-tear",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "will-mountain",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "scorpion-cut",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "wealth-sickness",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "age-subtract",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "glue-sky",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "park-night",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "sigh-low",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "treat-fish",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "slack-white",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "toy-girl",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "dig-cat",
                "condition": "Unrelated",
                "block": "B",
                "correct_response": "yes"
              },
              {
                "stim": "hoy-wappy",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "geaf-ster",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "wone-brapes",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "jance-maltz",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "fot-thip",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "ren-onk",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "goid-nad",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "fop-skup",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "rin-mear",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "hilp-bountain",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "scyssors-cet",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "dealth-fickness",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "ald-rubtract",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "darl-nighp",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "figh-lew",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "frout-hish",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "block-whote",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "bey-wirl",
                "condition": "Nonword",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "man-wotar",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "rough-smoat",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "bread-bottin",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "bitter-sweax",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "green-gliss",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "large-smipo",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "bed-slorg",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "afraid-scobet",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "cabbage-lottir",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "door-wingew",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "moship-father",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "neibon-thread",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "brothog-sister",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "capsute-pill",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "boeh-ale",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "bosh-water",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "nirey-south",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "honip-bee",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "sconix-marble",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              },
              {
                "stim": "porry-cent",
                "condition": "Filler",
                "block": "B",
                "correct_response": "no"
              }
            ],
            "sample": {
              "mode": "draw-shuffle"
            },
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Block B Loop",
            "skip": "${parameters.counterbalance != 2}",
            "shuffleGroups": [],
            "template": {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Trial",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 18.69,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black",
                      "text": "+",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Fixation",
                  "timeout": "500"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.35,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black",
                      "text": "${ parameters.stim }",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(y)": "yes",
                    "keypress(n)": "no"
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Stimulus",
                  "correctResponse": "${ parameters.correct_response }"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 585.65,
                      "height": 56.5,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "${ state.correct ? '😃' : '☹️'}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "50",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "ISI",
                  "timeout": "500",
                  "tardy": true
                }
              ]
            }
          },
          {
            "type": "lab.flow.Loop",
            "templateParameters": [
              {
                "stim": "church-steeple",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "law-justice",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "sheep-lamb",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "eat-food",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "insect-bug",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "frown-smile",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "fruit-apple",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "square-box",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "village-town",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "hand-foot",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "ice-snow",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "baby-child",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "moon-star",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "oil-gas",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "thought-mind",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "play-work",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "shallow-deep",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "egg-yolk",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "pain-hurt",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "sharp-dull",
                "condition": "Related",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "weasel-bird",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "churn-steeple",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "paw-justice",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "steep-lamb",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "ear-food",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "invest-bug",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "brown-smile",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "stout-apple",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "squash-box",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "pillage-town",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "land-foot",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "ace-snow",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "busy-child",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "mood-star",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "foil-gas",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "fought-mind",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "slay-work",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "hallow-deep",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "peg-yolk",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "gain-hurt",
                "condition": "Unrelated",
                "block": "C",
                "correct_response": "yes"
              },
              {
                "stim": "hird-seft",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "eable-wird",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "chorch-steeble",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "liw-justoce",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "sheex-famb",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "eas-jood",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "onsect-fug",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "browt-smice",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "fruid-asple",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "squame-bor",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "villane-towp",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "yand-foox",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "oce-snaw",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "boby-shild",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "hoon-stad",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "oim-tas",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "thoughf-mand",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "galy-hork",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "shandow-meep",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "ege-bolk",
                "condition": "Nonword",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "man-wotar",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "rough-smoat",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "bread-bottin",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "bitter-sweax",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "green-gliss",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "large-smipo",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "bed-slorg",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "afraid-scobet",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "cabbage-lottir",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "door-wingew",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "moship-father",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "neibon-thread",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "brothog-sister",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "capsute-pill",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "boeh-ale",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "bosh-water",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "nirey-south",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "honip-bee",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "sconix-marble",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              },
              {
                "stim": "porry-cent",
                "condition": "Filler",
                "block": "C",
                "correct_response": "no"
              }
            ],
            "sample": {
              "mode": "draw-shuffle"
            },
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Block C Loop",
            "skip": "${parameters.counterbalance != 3}",
            "shuffleGroups": [],
            "template": {
              "type": "lab.flow.Sequence",
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Trial",
              "content": [
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 18.69,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black",
                      "text": "+",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Fixation",
                  "timeout": "500"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 286.35,
                      "height": 36.16,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "black",
                      "text": "${ parameters.stim }",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": 32,
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "keypress(y)": "yes",
                    "keypress(n)": "no"
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "Stimulus",
                  "correctResponse": "${ parameters.correct_response }"
                },
                {
                  "type": "lab.canvas.Screen",
                  "content": [
                    {
                      "type": "i-text",
                      "left": 0,
                      "top": 0,
                      "angle": 0,
                      "width": 585.65,
                      "height": 56.5,
                      "stroke": null,
                      "strokeWidth": 1,
                      "fill": "#000000",
                      "text": "${ state.correct ? '😃' : '☹️'}",
                      "fontStyle": "normal",
                      "fontWeight": "normal",
                      "fontSize": "50",
                      "fontFamily": "sans-serif",
                      "lineHeight": 1.16,
                      "textAlign": "center"
                    }
                  ],
                  "viewport": [
                    800,
                    600
                  ],
                  "files": {},
                  "responses": {
                    "": ""
                  },
                  "parameters": {},
                  "messageHandlers": {},
                  "title": "ISI",
                  "timeout": "500",
                  "tardy": true
                }
              ]
            }
          }
        ]
      }
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())