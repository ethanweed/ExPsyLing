// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 778.87,
          "height": 455.62,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "You will read some stories,\none sentence at a time.\n\nPress space to advance to the next sentence.\nYou can't go back to earlier sentences.\n\nAfter each story, you will see a word in blue.\nClick the green \"yes\" if you saw the word in the story\nClick the red \"no\" if you didn't see the word in the story.\n\nPress space to begin",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Space)": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "counterbalance": "1",
          "": ""
        },
        {
          "counterbalance": "2",
          "": ""
        }
      ],
      "sample": {
        "mode": "draw-shuffle",
        "n": "1"
      },
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Counterbalance",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Sequence",
        "content": [
          {
            "type": "lab.flow.Loop",
            "templateParameters": [
              {
                "sent": "Nick had a big test coming up.",
                "type": "filler",
                "position": "1"
              },
              {
                "sent": "But Nick was spending too much time at the gym.",
                "type": "filler",
                "position": "2"
              },
              {
                "sent": "He had finished playing basketball and it was time to work.",
                "type": "filler",
                "position": "3"
              },
              {
                "sent": "He planned to walk over to his dorm room to study.",
                "type": "filler",
                "position": "4"
              },
              {
                "sent": "Nick’s stomach was grumbling.",
                "type": "filler",
                "position": "5"
              },
              {
                "sent": "He had a lecture downloaded on his phone.",
                "type": "filler",
                "position": "6"
              },
              {
                "sent": "He decided it might be worth listening to one of the lectures on the way.",
                "type": "filler",
                "position": "7"
              },
              {
                "sent": "He put on his headphones and listened.",
                "type": "filler",
                "position": "8"
              },
              {
                "sent": "Nick listened to the introduction of a lecture.",
                "type": "short",
                "position": "9"
              },
              {
                "sent": "He turned off the lecture and pulled open the door.",
                "type": "filler",
                "position": "10"
              },
              {
                "sent": "He smelled some food cooking in the building.",
                "type": "filler",
                "position": "11"
              },
              {
                "sent": "His stomach seemed to gurgle in response to the smells.",
                "type": "filler",
                "position": "12"
              }
            ],
            "sample": {
              "mode": "sequential"
            },
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "nick_short",
            "tardy": true,
            "skip": "${parameters.counterbalance != 1}",
            "shuffleGroups": [],
            "template": {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 270.39,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "${parameters.sent}",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Screen"
            }
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 72.91,
                "height": 36.16,
                "stroke": "#0070d9",
                "strokeWidth": 1,
                "fill": "#0070d9",
                "text": "dorm",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "rect",
                "left": -150,
                "top": 150,
                "angle": 0,
                "width": 144.6,
                "height": 144.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "#a8ca09"
              },
              {
                "type": "i-text",
                "left": -150,
                "top": 150,
                "angle": 0,
                "width": 49.8,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "yes",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "rect",
                "left": 164,
                "top": 150,
                "angle": 0,
                "width": 144.6,
                "height": 144.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "#d6341a"
              },
              {
                "type": "i-text",
                "left": 162,
                "top": 150,
                "angle": 0,
                "width": 35.59,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "no",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "aoi",
                "left": -143.75,
                "top": 143.25,
                "angle": 0,
                "width": 184.8,
                "height": 184.8,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "yes"
              },
              {
                "type": "aoi",
                "left": 163,
                "top": 139,
                "angle": 0,
                "width": 184.8,
                "height": 184.8,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "no"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "mousedown @yes": "short_final",
              "mousedown @no": "short_final"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "probe",
            "tardy": true,
            "skip": "${parameters.counterbalance != 1}"
          },
          {
            "type": "lab.flow.Loop",
            "templateParameters": [
              {
                "sent": "Joe was working diligently on his term paper.",
                "type": "filler",
                "position": "1"
              },
              {
                "sent": "Joe had been laboring for quite some time in the library.",
                "type": "filler",
                "position": "2"
              },
              {
                "sent": "He began to feel kind of hungry.",
                "type": "filler",
                "position": "3"
              },
              {
                "sent": "He decided to get something to eat from the diner.",
                "type": "filler",
                "position": "4"
              },
              {
                "sent": "Joe gathered his things and left.",
                "type": "filler",
                "position": "5"
              },
              {
                "sent": "Outside, he noticed a stick on the ground.",
                "type": "filler",
                "position": "6"
              },
              {
                "sent": "He pulled out a small pocket knife from his bookbag.",
                "type": "filler",
                "position": "7"
              },
              {
                "sent": "Joe began to whittle away at the stick while he walked.",
                "type": "filler",
                "position": "8"
              },
              {
                "sent": "He carved the stick into a small flute.",
                "type": "long",
                "position": "9"
              },
              {
                "sent": "He put the finishing touches on it just as he arrived.",
                "type": "filler",
                "position": "10"
              },
              {
                "sent": "The smells of cooking burgers and french fries made his mouth water.",
                "type": "filler",
                "position": "11"
              },
              {
                "sent": "He stepped up to the counter and ordered a grilled cheese sandwich.",
                "type": "filler",
                "position": "12"
              }
            ],
            "sample": {
              "mode": "sequential"
            },
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "joe_long",
            "skip": "${parameters.counterbalance != 1}",
            "shuffleGroups": [],
            "template": {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 270.39,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "${parameters.sent}",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Screen"
            }
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 87.13,
                "height": 36.16,
                "stroke": "#0070d9",
                "strokeWidth": 1,
                "fill": "#0070d9",
                "text": "library",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "rect",
                "left": -150,
                "top": 150,
                "angle": 0,
                "width": 144.6,
                "height": 144.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "#a8ca09"
              },
              {
                "type": "i-text",
                "left": -150,
                "top": 150,
                "angle": 0,
                "width": 49.8,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "yes",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "rect",
                "left": 164,
                "top": 150,
                "angle": 0,
                "width": 144.6,
                "height": 144.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "#d6341a"
              },
              {
                "type": "i-text",
                "left": 162,
                "top": 150,
                "angle": 0,
                "width": 35.59,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "no",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "aoi",
                "left": -143.75,
                "top": 143.25,
                "angle": 0,
                "width": 184.8,
                "height": 184.8,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "yes"
              },
              {
                "type": "aoi",
                "left": 163,
                "top": 139,
                "angle": 0,
                "width": 184.8,
                "height": 184.8,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "no"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "mousedown @yes": "long_start",
              "mousedown @no": "long_start"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "probe",
            "tardy": true,
            "skip": "${parameters.counterbalance != 1}"
          },
          {
            "type": "lab.flow.Loop",
            "templateParameters": [
              {
                "sent": "Joe was working diligently on his term paper.",
                "type": "filler",
                "position": "1"
              },
              {
                "sent": "Joe had been laboring for quite some time in the library.",
                "type": "filler",
                "position": "2"
              },
              {
                "sent": "He began to feel kind of hungry.",
                "type": "filler",
                "position": "3"
              },
              {
                "sent": "He decided to get something to eat from the diner.",
                "type": "filler",
                "position": "4"
              },
              {
                "sent": "Joe gathered his things and left.",
                "type": "filler",
                "position": "5"
              },
              {
                "sent": "Outside, he noticed a stick on the ground.",
                "type": "filler",
                "position": "6"
              },
              {
                "sent": "He pulled out a small pocket knife from his bookbag.",
                "type": "filler",
                "position": "7"
              },
              {
                "sent": "Joe began to whittle away at the stick while he walked.",
                "type": "filler",
                "position": "8"
              },
              {
                "sent": "He carved his initials right on the stick.",
                "type": "short",
                "position": "9"
              },
              {
                "sent": "He put the finishing touches on it just as he arrived.",
                "type": "filler",
                "position": "10"
              },
              {
                "sent": "The smells of cooking burgers and french fries made his mouth water.",
                "type": "filler",
                "position": "11"
              },
              {
                "sent": "He stepped up to the counter and ordered a grilled cheese sandwich.",
                "type": "filler",
                "position": "12"
              }
            ],
            "sample": {
              "mode": "sequential"
            },
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "joe_short",
            "skip": "${parameters.counterbalance != 2}",
            "shuffleGroups": [],
            "template": {
              "type": "lab.flow.Loop",
              "templateParameters": [
                {
                  "sent": "Joe was working diligently on his term paper.",
                  "type": "filler",
                  "position": "1"
                },
                {
                  "sent": "Joe had been laboring for quite some time in the library.",
                  "type": "filler",
                  "position": "2"
                },
                {
                  "sent": "He began to feel kind of hungry.",
                  "type": "filler",
                  "position": "3"
                },
                {
                  "sent": "He decided to get something to eat from the diner.",
                  "type": "filler",
                  "position": "4"
                },
                {
                  "sent": "Joe gathered his things and left.",
                  "type": "filler",
                  "position": "5"
                },
                {
                  "sent": "Outside, he noticed a stick on the ground.",
                  "type": "filler",
                  "position": "6"
                },
                {
                  "sent": "He pulled out a small pocket knife from his bookbag.",
                  "type": "filler",
                  "position": "7"
                },
                {
                  "sent": "Joe began to whittle away at the stick while he walked.",
                  "type": "filler",
                  "position": "8"
                },
                {
                  "sent": "He carved his initials right on the stick.",
                  "type": "short",
                  "position": "9"
                },
                {
                  "sent": "He put the finishing touches on it just as he arrived.",
                  "type": "filler",
                  "position": "10"
                },
                {
                  "sent": "The smells of cooking burgers and french fries made his mouth water.",
                  "type": "filler",
                  "position": "11"
                },
                {
                  "sent": "He stepped up to the counter and ordered a grilled cheese sandwich.",
                  "type": "filler",
                  "position": "12"
                }
              ],
              "sample": {
                "mode": "sequential"
              },
              "files": {},
              "responses": {
                "": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Loop",
              "shuffleGroups": [],
              "template": {
                "type": "lab.canvas.Screen",
                "content": [
                  {
                    "type": "i-text",
                    "left": 0,
                    "top": 0,
                    "angle": 0,
                    "width": 270.39,
                    "height": 36.16,
                    "stroke": null,
                    "strokeWidth": 1,
                    "fill": "black",
                    "text": "${parameters.sent}",
                    "fontStyle": "normal",
                    "fontWeight": "normal",
                    "fontSize": 32,
                    "fontFamily": "sans-serif",
                    "lineHeight": 1.16,
                    "textAlign": "center"
                  }
                ],
                "viewport": [
                  800,
                  600
                ],
                "files": {},
                "responses": {
                  "keypress(Space)": ""
                },
                "parameters": {},
                "messageHandlers": {},
                "title": "Screen"
              }
            }
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 71.16,
                "height": 36.16,
                "stroke": "#0070d9",
                "strokeWidth": 1,
                "fill": "#0070d9",
                "text": "diner",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "rect",
                "left": -150,
                "top": 150,
                "angle": 0,
                "width": 144.6,
                "height": 144.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "#a8ca09"
              },
              {
                "type": "i-text",
                "left": -150,
                "top": 150,
                "angle": 0,
                "width": 49.8,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "yes",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "rect",
                "left": 164,
                "top": 150,
                "angle": 0,
                "width": 144.6,
                "height": 144.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "#d6341a"
              },
              {
                "type": "i-text",
                "left": 162,
                "top": 150,
                "angle": 0,
                "width": 35.59,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "no",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "aoi",
                "left": -143.75,
                "top": 143.25,
                "angle": 0,
                "width": 184.8,
                "height": 184.8,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "yes"
              },
              {
                "type": "aoi",
                "left": 163,
                "top": 139,
                "angle": 0,
                "width": 184.8,
                "height": 184.8,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "no"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "mousedown @yes": "short_start",
              "mousedown @no": "short_start"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "probe",
            "tardy": true,
            "skip": "${parameters.counterbalance != 2}"
          },
          {
            "type": "lab.flow.Loop",
            "templateParameters": [
              {
                "sent": "Nick had a big test coming up.",
                "type": "filler",
                "position": "1"
              },
              {
                "sent": "But Nick was spending too much time at the gym.",
                "type": "filler",
                "position": "2"
              },
              {
                "sent": "He had finished playing basketball and it was time to work.",
                "type": "filler",
                "position": "3"
              },
              {
                "sent": "He planned to walk over to his dorm room to study.",
                "type": "filler",
                "position": "4"
              },
              {
                "sent": "Nick’s stomach was grumbling.",
                "type": "filler",
                "position": "5"
              },
              {
                "sent": "He had a lecture downloaded on his phone",
                "type": "filler",
                "position": "6"
              },
              {
                "sent": "He decided it might be worth listening to one of the lectures on the way.",
                "type": "filler",
                "position": "7"
              },
              {
                "sent": "He put on his headphones and listened.",
                "type": "filler",
                "position": "8"
              },
              {
                "sent": "Nick listened to almost half of a lecture.",
                "type": "long",
                "position": "9"
              },
              {
                "sent": "He turned off the lecture and pulled open the door.",
                "type": "filler",
                "position": "10"
              },
              {
                "sent": "He smelled some food cooking in the building.",
                "type": "filler",
                "position": "11"
              },
              {
                "sent": "His stomach seemed to gurgle in response to the smells.",
                "type": "filler",
                "position": "12"
              }
            ],
            "sample": {
              "mode": "sequential"
            },
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "nick_long",
            "skip": "${parameters.counterbalance != 2}",
            "shuffleGroups": [],
            "template": {
              "type": "lab.canvas.Screen",
              "content": [
                {
                  "type": "i-text",
                  "left": 0,
                  "top": 0,
                  "angle": 0,
                  "width": 270.39,
                  "height": 36.16,
                  "stroke": null,
                  "strokeWidth": 1,
                  "fill": "black",
                  "text": "${parameters.sent}",
                  "fontStyle": "normal",
                  "fontWeight": "normal",
                  "fontSize": 32,
                  "fontFamily": "sans-serif",
                  "lineHeight": 1.16,
                  "textAlign": "center"
                }
              ],
              "viewport": [
                800,
                600
              ],
              "files": {},
              "responses": {
                "keypress(Space)": ""
              },
              "parameters": {},
              "messageHandlers": {},
              "title": "Screen"
            }
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 72.91,
                "height": 36.16,
                "stroke": "#0070d9",
                "strokeWidth": 1,
                "fill": "#0070d9",
                "text": "dorm",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "rect",
                "left": -150,
                "top": 150,
                "angle": 0,
                "width": 144.6,
                "height": 144.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "#a8ca09"
              },
              {
                "type": "i-text",
                "left": -150,
                "top": 150,
                "angle": 0,
                "width": 49.8,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "yes",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "rect",
                "left": 164,
                "top": 150,
                "angle": 0,
                "width": 144.6,
                "height": 144.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "#d6341a"
              },
              {
                "type": "i-text",
                "left": 162,
                "top": 150,
                "angle": 0,
                "width": 35.59,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "no",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "aoi",
                "left": -143.75,
                "top": 143.25,
                "angle": 0,
                "width": 184.8,
                "height": 184.8,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "yes"
              },
              {
                "type": "aoi",
                "left": 163,
                "top": 139,
                "angle": 0,
                "width": 184.8,
                "height": 184.8,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "no"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "mousedown @yes": "long_final",
              "mousedown @no": "long_final"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "probe",
            "tardy": true,
            "skip": "${parameters.counterbalance != 2}"
          }
        ]
      }
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())